//
//  CWBarDataSet.m
//  ChartJSWrapper
//
//  Created by András Gyetván on 22/03/15.
//  Copyright (c) 2015 Gyetván András. All rights reserved.
//

#import "CWBarDataSet.h"

@implementation CWBarDataSet
- (instancetype) init {
	self = [super init];
	return self;
}
@end
