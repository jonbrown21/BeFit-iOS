//
//  UserFoodRecords+CoreDataClass.m
//  BeFit iOS
//
//  Created by Satinder Singh on 2/27/17.
//  Copyright © 2017 Jon Brown. All rights reserved.
//

#import "UserFoodRecords+CoreDataClass.h"
#import "Food.h"
@implementation UserFoodRecords

@end
