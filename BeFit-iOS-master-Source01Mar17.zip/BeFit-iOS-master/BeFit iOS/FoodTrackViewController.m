//
//  FoodTrackViewController.m
//  BeFit iOS
//
//  Created by Satinder Singh on 2/21/17.
//  Copyright © 2017 Jon Brown. All rights reserved.
//

#import "FoodTrackViewController.h"

@implementation FoodTrackCell
@end
@interface FoodTrackViewController ()

@end

@implementation FoodTrackViewController
- (NSManagedObjectContext *)managedObjectContext {
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    return context;
}
- (void)loadView
{
    [super loadView];
    
//    _values							= @[@30, @45, @44, @60, @95, @2, @8, @9];
//    _newvalues = [NSMutableArray arrayWithObjects:@"Sunday",@"Monday",@"Monday",@"Monday",@"Monday",@"Monday",@"Monday",@"Monday",nil];
    _barColors						= @[[UIColor blueColor], [UIColor redColor], [UIColor blackColor], [UIColor orangeColor], [UIColor purpleColor], [UIColor greenColor]];
    _currentBarColor				= 0;
    
    CGRect chartFrame				= CGRectMake(0.0,
                                                 0.0,
                                                 300.0,
                                                 300.0);
    
    _chart							= [[SimpleBarChart alloc] initWithFrame:_simplechart.frame];
   
    _chart.delegate					= self;
    _chart.dataSource				= self;
    _chart.barShadowOffset			= CGSizeMake(2.0, 1.0);
    _chart.animationDuration		= 1.0;
    _chart.barShadowColor			= [UIColor grayColor];
    _chart.barShadowAlpha			= 0.5;
    _chart.barShadowRadius			= 1.0;
    _chart.barWidth					= 18.0;
    _chart.xLabelType				= SimpleBarChartXLabelTypeVerticle;
    _chart.incrementValue			= 400;
    _chart.barTextType				= SimpleBarChartBarTextTypeTop;
    _chart.barTextColor				= [UIColor blackColor];
    _chart.gridColor				= [UIColor grayColor];
     [self.view addSubview:_chart];
    
}

- (void)changeClicked
{
    NSMutableArray *valuesCopy = _values.mutableCopy;
//    [valuesCopy shuffle];
    
    _values = valuesCopy;
    
    if (_chart.xLabelType == SimpleBarChartXLabelTypeVerticle)
        _chart.xLabelType = SimpleBarChartXLabelTypeHorizontal;
    else
        _chart.xLabelType = SimpleBarChartXLabelTypeVerticle;
    
    _currentBarColor = ++_currentBarColor % _barColors.count;
    
    [_chart reloadData];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.title = @"Food Tracker";
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"whitey.png"]];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [AppDelegate ShowLoader];
    
    [self SetData];
    
    [_chart reloadData];
    [self.tableView reloadData];
    [AppDelegate HideLoader];
}

-(void)SetData
{
    _lblGoalCal.text = [NSString stringWithFormat:@"Goal\n%ld Cal", [[[NSUserDefaults standardUserDefaults] objectForKey:@"recommended-name"] integerValue]];
    _lblTotalCal.text = [NSString stringWithFormat:@"Today\n0 Cal"] ;
    x_values = [[NSMutableArray alloc] init];
    _values = [[NSMutableArray alloc] init];

    foodObjectArray = [[NSMutableArray alloc] init];
    servingsArray= [[NSMutableArray alloc] init];
    NSInteger grossCal = 0 ;
    for (int iCount = 0; iCount< 7; iCount++)
    {
        NSDateFormatter *format = [[NSDateFormatter alloc] init];
        [format setDateFormat:@"MM/dd/yyyy-EEEE"];
       
        NSString* dateStr = [format stringFromDate:[NSDate dateWithTimeIntervalSinceNow: -(60.0f*60.0f*24.0f* iCount)]] ;
        NSArray* arr = [dateStr componentsSeparatedByString:@"-"];
        [x_values addObject:arr[1]];
        NSInteger totalCal = 0 ;
        
        NSArray* food_record = [self GetFoodItem:arr[0]];
        NSMutableArray* todaysItems = [[NSMutableArray alloc] init];
        for (int zCount = 0; zCount< food_record.count; zCount++)
        {
            UserFoodRecords* record = food_record[zCount] ;
            NSSet* foodSet = record.foodIntake ;
            NSArray* items = [foodSet allObjects];
            
            for (int jCount = 0 ; jCount < items.count; jCount++)
            {
                Food* food = [items objectAtIndex:jCount];
                
                totalCal = totalCal + (food.calories.integerValue * record.servings.integerValue) ;
                
            }
            
            if (iCount == 0)
            {
                [servingsArray addObject:[NSNumber numberWithInteger: record.servings.integerValue ]];
                [todaysItems addObjectsFromArray:items];
            }
        }
        if (iCount == 0)
        {
            _lblTotalCal.text = [NSString stringWithFormat:@"Today\n%ld Cal", (long)totalCal] ;
            foodObjectArray = [[NSMutableArray alloc] initWithArray:todaysItems];
        }
        
        
        
        grossCal = grossCal + totalCal;
        [_values addObject:[NSNumber numberWithInteger:totalCal ]];
        
    }
    
    _lblAverageCal.text = [NSString stringWithFormat:@"Average\n%ld Cal", grossCal/7 ] ;
    
    x_values =[NSMutableArray arrayWithArray: [[x_values reverseObjectEnumerator] allObjects]];
    _values =[NSMutableArray arrayWithArray: [[_values reverseObjectEnumerator] allObjects]];
}
//NSArray* reversedArray = [[startArray reverseObjectEnumerator] allObjects];
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark SimpleBarChartDataSource

- (NSUInteger)numberOfBarsInBarChart:(SimpleBarChart *)barChart
{
    return _values.count;
}

- (CGFloat)barChart:(SimpleBarChart *)barChart valueForBarAtIndex:(NSUInteger)index
{
    if ([[_values objectAtIndex:index] integerValue] < [[[NSUserDefaults standardUserDefaults] objectForKey:@"recommended-name"] integerValue])
    {
        thresholdValue = true;
    }
    
    return [[_values objectAtIndex:index] floatValue];
}

- (NSString *)barChart:(SimpleBarChart *)barChart textForBarAtIndex:(NSUInteger)index
{
    return [[_values objectAtIndex:index] stringValue];
}

- (NSString *)barChart:(SimpleBarChart *)barChart xLabelForBarAtIndex:(NSUInteger)index
{
    
    return [x_values objectAtIndex:index] ;
}

- (UIColor *)barChart:(SimpleBarChart *)barChart colorForBarAtIndex:(NSUInteger)index
{
    if (thresholdValue)
    {
        return [UIColor redColor];
    }
    return [_barColors objectAtIndex:_currentBarColor];
}


-(NSArray*)GetFoodItem:(NSString*)dateStr
{
    id appDelegate =(id)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *context =[appDelegate managedObjectContext];
    NSEntityDescription* entity=[NSEntityDescription entityForName:@"UserFoodRecords" inManagedObjectContext:context];
    NSFetchRequest* request=[[NSFetchRequest alloc]init];
    
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"date LIKE[c] %@",dateStr];
    [request setPredicate:predicate];
    
    
    [request setEntity:entity];
    NSError* error;
    NSArray* data=[ context executeFetchRequest:request error:&error];
    return data;
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return foodObjectArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    // Configure the cell...
    static NSString *cellIdentifier = @"Cell";

    FoodTrackCell *cell =(FoodTrackCell*) [self.tableView dequeueReusableCellWithIdentifier:cellIdentifier ];
    
    cell.accessoryView = nil;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    Food* food = [foodObjectArray objectAtIndex:indexPath.row];
    cell.lblFoodName.text = food.name ;
    NSInteger totalCals = [servingsArray[indexPath.row] integerValue];
    cell.lblCal.text = [NSString stringWithFormat:@"%ld Cal", (food.calories.integerValue * totalCals) ] ;
    cell.lblServings.text = [NSString stringWithFormat:@"Total Servings: %@",servingsArray[indexPath.row]] ;
    return cell;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    
    return @"Today's Intake" ;
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
