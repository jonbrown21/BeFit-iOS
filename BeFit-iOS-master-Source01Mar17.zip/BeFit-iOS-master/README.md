BeFit-iOS
=========
Future home of the BeFit iOS App

Goals
=========

1. To create a simple to use iOS app that will interface / sync with the BeFit Mac OSX App.
2. App would be a free tool to search and update lists.
3. App would be a free scanner that could import food items while shopping by scanning the nutrition facts label of food items.
