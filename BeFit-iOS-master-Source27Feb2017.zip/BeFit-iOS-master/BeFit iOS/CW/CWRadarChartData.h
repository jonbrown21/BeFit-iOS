//
//  CWRadarChartData.h
//  ChartJSWrapper
//
//  Created by András Gyetván on 22/03/15.
//  Copyright (c) 2015 Gyetván András. All rights reserved.
//

#import "CWLineChartData.h"

@interface CWRadarChartData : CWLineChartData

@end
