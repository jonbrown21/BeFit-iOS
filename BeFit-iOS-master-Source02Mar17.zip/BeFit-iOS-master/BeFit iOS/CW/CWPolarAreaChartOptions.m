//
//  CWPolarAreaChartOptions.m
//  ChartJSWrapper
//
//  Created by András Gyetván on 22/03/15.
//  Copyright (c) 2015 Gyetván András. All rights reserved.
//

#import "CWPolarAreaChartOptions.h"

@implementation CWPolarAreaChartOptions
@dynamic scaleBeginAtZero;
@dynamic animationSteps;
@dynamic animationEasing;

- (instancetype) init {
	self = [super init];
	return self;
}

@end
