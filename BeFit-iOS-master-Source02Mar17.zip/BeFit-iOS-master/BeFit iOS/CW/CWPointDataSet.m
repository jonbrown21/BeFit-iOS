//
//  CWPointDataSet.m
//  ChartJSWrapper
//
//  Created by András Gyetván on 21/03/15.
//  Copyright (c) 2015 Gyetván András. All rights reserved.
//

#import "CWPointDataSet.h"

@implementation CWPointDataSet
- (instancetype) init {
	self = [super init];
	return self;
}

//- (instancetype) initWithData:(NSArray*)data {
//	self = [super init];
//	if(self) {
//		_data = [NSArray arrayWithArray:data];
//	}
//	return self;
//}

@end
