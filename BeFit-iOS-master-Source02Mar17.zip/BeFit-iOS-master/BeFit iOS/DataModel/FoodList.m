//
//  FoodList.m
//  BeFit iOS
//
//  Created by Jon Brown on 9/21/14.
//  Copyright (c) 2014 Jon Brown. All rights reserved.
//

#import "FoodList.h"
#import "Food.h"


@implementation FoodList

@dynamic name;
@dynamic orderIndex;
@dynamic foods;

@end
