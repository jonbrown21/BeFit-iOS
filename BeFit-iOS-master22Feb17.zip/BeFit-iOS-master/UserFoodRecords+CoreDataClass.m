//
//  UserFoodRecords+CoreDataClass.m
//  BeFit iOS
//
//  Created by Satinder Singh on 2/20/17.
//  Copyright © 2017 Jon Brown. All rights reserved.
//

#import "UserFoodRecords+CoreDataClass.h"

@implementation UserFoodRecords

@end
