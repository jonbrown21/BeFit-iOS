//
//  CWRadarChartOptions.m
//  ChartJSWrapper
//
//  Created by András Gyetván on 22/03/15.
//  Copyright (c) 2015 Gyetván András. All rights reserved.
//

#import "CWRadarChartOptions.h"

@implementation CWRadarChartOptions
@dynamic scaleShowLabels;
@dynamic scaleBeginAtZero;

- (instancetype) init {
	return [super init];
}
@end
