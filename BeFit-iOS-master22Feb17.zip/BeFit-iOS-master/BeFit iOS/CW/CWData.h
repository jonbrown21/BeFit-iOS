//
//  CWData.h
//  ChartJSWrapper
//
//  Created by András Gyetván on 20/03/15.
//  Copyright (c) 2015 Gyetván András. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CWObject.h"
@interface CWData : CWObject
//- (NSString*) JSON;
@end
