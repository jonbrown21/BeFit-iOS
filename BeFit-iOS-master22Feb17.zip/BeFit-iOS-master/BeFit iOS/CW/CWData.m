//
//  CWData.m
//  ChartJSWrapper
//
//  Created by András Gyetván on 20/03/15.
//  Copyright (c) 2015 Gyetván András. All rights reserved.
//

#import "CWData.h"

@interface CWData ()

@end

@implementation CWData
//- (NSString*) JSON {
//	NSData *dataJSON = [NSJSONSerialization dataWithJSONObject:[self asJSONObject] options:NSJSONWritingPrettyPrinted error:nil];
//	NSString *stringJSON = [[NSString alloc] initWithData:dataJSON encoding:NSUTF8StringEncoding];
//	return stringJSON;
//}

@end
