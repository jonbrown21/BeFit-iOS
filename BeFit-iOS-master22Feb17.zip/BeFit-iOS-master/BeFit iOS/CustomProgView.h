//
//  CustomProgView.h
//  BeFit iOS
//
//  Created by Jon on 1/24/17.
//  Copyright © 2017 Jon Brown. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomProgView : UIProgressView

@end
